//Phurithip Paisanworajit 67070503437
#include<stdio.h>
int  main(){
    int value;
    scanf("%d",&value);
    if(value%2==1){
        printf("Odd");
    }
     if(value%2==0){
        printf("Even");
    }
}