//Phurithip Paisanworajit 67070503437
#include<stdio.h>
int main(){
    int num;
    scanf("%d",&num);
    if(num >= 10 && num <= 100){
        printf("Yes");
    }
    else {
        printf("No");
    }
   return 0;
}